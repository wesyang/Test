package com.persist.uw.examples

object Simplify {

  // use pattern matching
  // no vars or mutable data
  // pass all tests

  def simplify(t: Tree3): Tree3 = ???
}

