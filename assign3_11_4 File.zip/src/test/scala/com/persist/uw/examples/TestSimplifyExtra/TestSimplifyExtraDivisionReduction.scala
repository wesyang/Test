package com.persist.uw.examples.TestSimplifyExtra

import com.persist.uw.examples._
import org.specs2.mutable

/**
  * Created by wesyang on 11/3/2016.
  */
class TestSimplifyExtraDivisionReduction extends mutable.Specification {

  import Simplify.simplify

  "Testcase:((b * a) / (b * 3)) ==  (a / 3)" >> {
    val a = Name3("a")
    val b = Name3("b")
    val top = Multiply3(b ,a )
    val bottom = Multiply3(b, Int3(3))
    val expr = Divide3(top, bottom)
    val r =simplify(expr)
    r shouldEqual( Divide3 (a, Int3(3)))
  }

  "Testcase:((b * a) / b) ==  a" >> {
    val a = Name3("a")
    val b = Name3("b")
    val top = Multiply3(b ,a )
    val bottom = b
    val expr = Divide3(top, bottom)
    val r =simplify(expr)
    r shouldEqual(a)
  }

  "Testcase:(a / (b * a)) ==  (1 / b)" >> {
    val a = Name3("a")
    val b = Name3("b")
    val top = Multiply3(b ,a )
    val expr = Divide3(a, top)
    val r =simplify(expr)
    r shouldEqual( Divide3(Int3(1), b))
  }

  "Testcase: (a / (a / b)) ==  b" >> {
    val a = Name3("a")
    val b = Name3("b")
    val top = Divide3(a ,b )
    val expr = Divide3(a, top)
    val r =simplify(expr)
    r shouldEqual( b)
  }
}